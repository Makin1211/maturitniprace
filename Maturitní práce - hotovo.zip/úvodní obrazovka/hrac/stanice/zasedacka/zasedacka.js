const playerName = localStorage.getItem("playerName") || "Hráč";
const dialogues = [
    { name: playerName, text: "Zdravím, už jsem tady.", img: "charMartin" },
    { name: "Veru", text: "Vida, " + playerName +  ", no konečně.", img: "charVeru" },
    { name: "Mata", text: "Aha, " + playerName + ", Kde se loudáš?", img: "charMata" },
    { name: playerName, text: "Omlouvám se, nestíhám.", img: "charMartin" },
    { name: "Mata", text: "V pohodě, nic se neděje, neplánovali jsme tuto zasedačku.", img: "charMata" },
    { name: playerName, text: "Co se stalo?", img: "charMartin" },
    { name: "Veru", text: "Našlo se pár mrtvých lidí, další jsou v nemocnici, všichni otrava methanolem.", img: "charVeru" },
    { name: "Mata", text: "Přesně tak, jak jste už asi zjistili ze včerejších zpráv, někdo namýchal methanol s ethanolem a prodává to.", img: "charMata" },
    { name: playerName, text: "Co? Koho by to vůbec napadlo?", img: "charMartin" },
    { name: "Veru", text: "To jsem si taky říkala, ale nějaký idiot se tu najde.", img: "charVeru" },
    { name: "Mata", text:"Tento případ dostane " + playerName + "a Veru, je to vaše, zkuste to vyřešit co nejdřív.", img: "charMata" },
    { name: playerName, text: "Rozkaz šéfová.", img: "charMartin" },
    { name: "Veru", text: "Jdeme na to.", img: "charVeru" },
];

let index = 0;
function showNextLine() {
    if (index < dialogues.length) {
        const line = dialogues[index];
        const dialogDiv = document.getElementById("dialog");
        dialogDiv.innerHTML = `<strong>${line.name}:</strong> <span class="message">${line.text}</span>`;

        document.getElementById("charMartin").classList.remove("show-left", "show-right");
        document.getElementById("charVeru").classList.remove("show-left", "show-right");
        document.getElementById("charMata").classList.remove("show-left", "show-right");
        
        const charImg = document.getElementById(line.img);
        if (line.img === "charMartin") {
            charImg.classList.add("show-left");
        } else {
            charImg.classList.add("show-right");
        }
        index++;
    } else {
        document.getElementById("dialog").innerHTML = "<em>Konec dialogu.</em>";
        document.getElementById("next-button").style.display = "none";
        document.getElementById("nextPageButton").style.display = "inline-block";
    }
}

document.getElementById("next-button").addEventListener("click", showNextLine);
showNextLine();