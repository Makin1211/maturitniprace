const playerName = localStorage.getItem("playerName") || "Hráč";
const dialogues = [
    { name: playerName, text: "Takže, co nám k tomu řeknete.", img: "charMartin" },
    { name: "Veru", text: "Víte kolik lidí kvůli vám umřelo a kolik ještě může umřít?", img: "charVeru" },
    { name: "Pilát", text: "Já myslel, že se nic nestane.", img: "charPilat" },
    { name: playerName, text: "Jo, tak ty sis myslel, ale ti lidé v nemocnici mluví za vše.", img: "charMartin" },
    { name: "Veru", text: "proč jsi to vlastně udělal?", img: "charVeru" },
    { name: "Pilát", text: "Chtěl jsem si přividělat", img: "charPilat" },
    { name: "Pilát", text: "A četl jsem na internetu, že když se methanol smíchá s ethanolem tak se to vynuluje.", img: "charPilat" },
    { name: playerName, text: "Tak ty jsi dobrý chemik.", img: "charMartin" },
    { name: "Veru", text: "Hodně blbý nápad.", img: "charVeru" },
    { name: "Pilát", text: "Já vím, nečekal jsem, že se něco stane takového.", img: "charPilat" },
    { name: "Pilát", text: "Mrzí mě to.", img: "charPilat" },
    { name: playerName, text: "To by teda mělo!!", img: "charMartin" },
    { name: "Veru", text: "Za toto půjdeš sedět...", img: "charVeru" }
];

let index = 0;
function showNextLine() {
    if (index < dialogues.length) {
        const line = dialogues[index];
        const dialogDiv = document.getElementById("dialog");
        dialogDiv.innerHTML = `<strong>${line.name}:</strong> <span class="message">${line.text}</span>`;

        document.getElementById("charMartin").classList.remove("show-left", "show-right");
        document.getElementById("charVeru").classList.remove("show-left", "show-right");
        document.getElementById("charPilat").classList.remove("show-left", "show-right");
        
        const charImg = document.getElementById(line.img);
        if (line.img === "charMartin") {
            charImg.classList.add("show-left");
        } else {
            charImg.classList.add("show-right");
        }
        index++;
    } else {
        document.getElementById("dialog").innerHTML = "<em>Konec dialogu.</em>";
        document.getElementById("next-button").style.display = "none";
        document.getElementById("nextPageButton").style.display = "inline-block";
    }
}

document.getElementById("next-button").addEventListener("click", showNextLine);
showNextLine();