const playerName = localStorage.getItem("playerName") || "Hráč";
const dialogues = [
    { name: playerName, text: "Dobrý den", img: "charMartin" },
    { name: "Veru", text: "Dobrý den, pane Pilát.", img: "charVeru" },
    { name: playerName, text: "Tady ta tisíci litrová nádrž je vaše?", img: "charMartin" },
    { name: "Pilát", text: "Ano, proč se ptáte?", img: "charPilat" },
    { name: playerName, text: "Našli jsme v ní methanol, jste podezřelý z vraždy a podvodu", img: "charMartin" },
    { name: "Veru", text: "Máte právo nevypovídat", img: "charVeru" },
    { name: "Pilát", text: "Sakra...", img: "charPilat" }
];

let index = 0;

function startConversation() {
    document.getElementById("startButton").style.display = "none";
    document.querySelector(".character-container").style.display = "block";
    document.querySelector(".dialog-container").style.display = "block";
    showNextLine();
}

function showNextLine() {
    if (index < dialogues.length) {
        const line = dialogues[index];
        const dialogDiv = document.getElementById("dialog");
        dialogDiv.innerHTML = `<strong>${line.name}:</strong> <span class="message">${line.text}</span>`;

        // Reset všech postav
        document.getElementById("charMartin").classList.remove("show-left", "show-right");
        document.getElementById("charVeru").classList.remove("show-left", "show-right");
        document.getElementById("charPilat").classList.remove("show-left", "show-right");

        // Zobrazení aktuální postavy
        const charImg = document.getElementById(line.img);
        if (line.img === "charMartin") {
            charImg.classList.add("show-left");
        } else {
            charImg.classList.add("show-right");
        }

        index++;
    } else {
        document.getElementById("dialog").innerHTML = "<em>Konec dialogu.</em>";
        document.getElementById("next-button").style.display = "none";
        
        // Zobrazení tlačítka pro další stránku s animací
        const nextPageContainer = document.getElementById("nextPageContainer");
        nextPageContainer.style.display = "block";
        nextPageContainer.style.animation = "fadeIn 0.5s ease-in-out";
    }
}
