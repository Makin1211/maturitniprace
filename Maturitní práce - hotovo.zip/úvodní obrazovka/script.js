document.getElementById("goToPage1").addEventListener("click", function() {
    window.location.href = "hrac/html.html"; 
});

document.getElementById("goToPage2").addEventListener("click", function() {
    window.location.href = "jakhrat/jakhrat.html"; 
});

document.getElementById("goToPage3").addEventListener("click", function() {
    window.location.href = "credits/credits.html"; 
});

document.getElementById("goToPage4").addEventListener("click", function() {
    window.location.href = "postavy/postavy.html"; 
});