const dialog = [
    { name: "Martin", text: "Ahoj, jak se máte?", img: "charMartin" },
    { name: "Veru", text: "Ahoj Martin, máme se dobře! A co ty?", img: "charVeru" },
    { name: "Mata", text: "Ahoj všichni! Jaký je dnešní plán?", img: "charMata" },
    { name: "Martin", text: "Chystáme se na výlet, co ty?", img: "charMartin" },
    { name: "Veru", text: "Myslím, že bychom mohli jet na hory.", img: "charVeru" },
    { name: "Mata", text: "Skvélé! To bych rád! Jaké hory?", img: "charMata" },
    { name: "Martin", text: "Možná Krkonošsko. Co myslíte?", img: "charMartin" },
    { name: "Veru", text: "Zní to perfektně.", img: "charVeru" },
    { name: "Mata", text: "Souhlasím! Jsem pro!", img: "charMata" }
];

let index = 0;

function showNextLine() {
    if (index < dialog.length) {
        const line = dialog[index];
        const dialogDiv = document.getElementById("dialog");
        
        dialogDiv.innerHTML = `<strong>${line.name}:</strong> <span class="message">${line.text}</span>`;
        
        // Skryje všechny obrázky postav
        document.getElementById("charMartin").classList.remove("show-left");
        document.getElementById("charVeru").classList.remove("show-right");
        document.getElementById("charMata").classList.remove("show-right");

        // Zobrazí obrázek postavy
        const charImg = document.getElementById(line.img);
        if (line.img === "charMartin") {
            charImg.classList.add("show-left"); // Martin se objeví zleva
        } else {
            charImg.classList.add("show-right"); // Ostatní postavy z prava
        }

        index++;
    } else {
        document.getElementById("dialog").innerHTML = "<em>Konec dialogu.</em>";
        document.querySelector(".next-button").style.display = "none";

        // Zobrazí tlačítko pro přechod na jinou stránku
        document.getElementById("nextPageButton").style.display = "inline-block";
        
        // Skryje obrázky postav
        document.getElementById("charMartin").classList.remove("show-left");
        document.getElementById("charVeru").classList.remove("show-right");
        document.getElementById("charMata").classList.remove("show-right");
    }
}

showNextLine();
