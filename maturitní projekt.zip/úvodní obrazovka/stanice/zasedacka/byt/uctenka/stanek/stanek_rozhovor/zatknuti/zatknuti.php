<!DOCTYPE html>
<html lang="cs">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stánek</title>
    <link rel="stylesheet" href="zatcen.css">
</head>

<body background="stanecek_obr/stanek.png">

    <!-- Tlačítko pro spuštění rozhovoru -->
    <div class="start-container">
        <button id="startButton" class="start-button" onclick="startConversation()">Spustit rozhovor</button>
    </div>

    <!-- Postavy -->
    <div class="character-container" style="display: none;">
        <img id="charMartin" class="character-img left" src="https://via.placeholder.com/200/FF5733/FFFFFF?text=Martin" alt="Martin">
        <img id="charVeru" class="character-img right" src="https://via.placeholder.com/200/338DFF/FFFFFF?text=Veru" alt="Veru">
        <img id="charProdavac" class="character-img right2" src="https://via.placeholder.com/200/FFFF33/FFFFFF?text=Prodava%C4%8D" alt="Prodavač">
    </div>

    <!-- Dialogové okno -->
    <div class="dialog-container" style="display: none;">
        <div id="dialog"></div>
        <button class="next-button" onclick="showNextLine()">Další</button>
    </div>

    <!-- Tlačítko pro přechod na další stránku -->
    <div class="next-page-container">
        <a id="nextPageButton" href="vyslech/vyslech.php" class="next-page-button" style="display:none;">Přejít na další stránku</a>
    </div>

    <script src="zatknuti.js"></script>

</body>

</html>
