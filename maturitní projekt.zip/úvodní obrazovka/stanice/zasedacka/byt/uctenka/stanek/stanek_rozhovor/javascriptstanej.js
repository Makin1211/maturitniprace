const dialog = [
    { name: "Martin", text: "Ahoj, jak se máš?", img: "charMartin" },
    { name: "Veru", text: "Ahoj Martin, mám se dobře! A co ty?", img: "charVeru" },
    { name: "Martin", text: "Taky se mám dobře, děkuji za optání.", img: "charMartin" },
    { name: "Veru", text: "Co plánuješ na dnešek?", img: "charVeru" },
    { name: "Martin", text: "Myslel jsem, že bychom mohli jít na procházku.", img: "charMartin" },
    { name: "Prodavač", text: "Dobrý den, hledáte něco konkrétního?", img: "charProdavac" },
    { name: "Veru", text: "Dobrý den, chceme koupit nějaké ovoce.", img: "charVeru" },
    { name: "Martin", text: "Ano, hledáme nějaké čerstvé jablka.", img: "charMartin" },
    { name: "Prodavač", text: "Máme skvělé jablka, rád vám je doporučím!", img: "charProdavac" },
    { name: "Veru", text: "Perfektní, vezmeme je!", img: "charVeru" }
];

let index = 0;

function showNextLine() {
    if (index < dialog.length) {
        const line = dialog[index];
        const dialogDiv = document.getElementById("dialog");
        
        dialogDiv.innerHTML = `<strong>${line.name}:</strong> <span class="message">${line.text}</span>`;
        
        // Skryje všechny obrázky postav
        document.getElementById("charMartin").classList.remove("show-left");
        document.getElementById("charVeru").classList.remove("show-right");
        document.getElementById("charProdavac").classList.remove("show-right");

        // Zobrazí obrázek postavy
        const charImg = document.getElementById(line.img);
        if (line.img === "charMartin") {
            charImg.classList.add("show-left"); // Martin se objeví zleva
        } else {
            charImg.classList.add("show-right"); // Veru a Prodavač z prava
        }

        index++;
    } else {
        document.getElementById("dialog").innerHTML = "<em>Konec dialogu.</em>";
        document.querySelector(".next-button").style.display = "none";

        // Zobrazí tlačítko pro přechod na jinou stránku
        document.getElementById("nextPageButton").style.display = "inline-block";
        
        // Skryje obrázky postav
        document.getElementById("charMartin").classList.remove("show-left");
        document.getElementById("charVeru").classList.remove("show-right");
        document.getElementById("charProdavac").classList.remove("show-right");
    }
}

showNextLine();
