const dialog = [
    { name: "Martin", text: "Ahoj, jak se máš?", img: "charMartin" },
    { name: "Veru", text: "Ahoj Martin, mám se dobře! A co ty?", img: "charVeru" },
    { name: "Martin", text: "Taky se mám dobře, děkuji za optání.", img: "charMartin" },
    { name: "Veru", text: "Co plánuješ na dnešek?", img: "charVeru" },
    { name: "Martin", text: "Myslel jsem, že bychom mohli jít na procházku.", img: "charMartin" },
    { name: "Prodavač", text: "Dobrý den, hledáte něco konkrétního?", img: "charProdavac" },
    { name: "Veru", text: "Dobrý den, chceme koupit nějaké ovoce.", img: "charVeru" },
    { name: "Martin", text: "Ano, hledáme nějaké čerstvé jablka.", img: "charMartin" },
    { name: "Prodavač", text: "Máme skvělé jablka, rád vám je doporučím!", img: "charProdavac" },
    { name: "Veru", text: "Perfektní, vezmeme je!", img: "charVeru" }
];

let index = 0;

function startConversation() {
    document.getElementById("startButton").style.display = "none";
    document.querySelector(".character-container").style.display = "block";
    document.querySelector(".dialog-container").style.display = "block";
    showNextLine();
}

function showNextLine() {
    if (index < dialog.length) {
        const line = dialog[index];
        const dialogDiv = document.getElementById("dialog");

        dialogDiv.innerHTML = `<strong>${line.name}:</strong> <span class="message">${line.text}</span>`;

        // Skryje všechny obrázky postav
        document.querySelectorAll(".character-img").forEach(img => {
            img.classList.remove("show-left", "show-right");
        });

        // Zobrazí odpovídající obrázek postavy
        const charImg = document.getElementById(line.img);
        if (charImg) {
            charImg.classList.add(line.img === "charMartin" ? "show-left" : "show-right");
        }

        index++;
    } else {
        endDialog();
    }
}

function endDialog() {
    document.getElementById("dialog").innerHTML = "<em>Konec dialogu.</em>";
    document.querySelector(".next-button").style.display = "none";
    document.getElementById("nextPageButton").style.display = "inline-block";

    document.querySelectorAll(".character-img").forEach(img => {
        img.classList.remove("show-left", "show-right");
    });
}
