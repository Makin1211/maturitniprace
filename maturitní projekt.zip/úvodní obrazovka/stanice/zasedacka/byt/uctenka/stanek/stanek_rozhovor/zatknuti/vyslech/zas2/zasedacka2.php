<?php
// Definování seznamu zpráv
$messages = [
    ["text" => "Velitel: Ale, Martin, zase pozde?", "sender" => "character1"],
    ["text" => "Martin: Pardon šéfe, nevěděl jsem, že je zasedání", "sender" => "character2"],
    ["text" => "Velitel: V pohodě, toto je mmimořádné zasedání", "sender" => "character1"],
    ["text" => "Velitel: Chlapi, máme tu problém, asi jste všichni viděli včerejší zprávy", "sender" => "character1"],
    [ "text" => "Veru: já je viděla, máte namysli ten methanol?", "sender" => "character3" ],
    [ "text" => "Velitel: Přesně, lidé umírají a my nevíme, kolik toho je", "sender" => "character1" ],
    [ "text" => "Frolix: Takže to znamená, že můžou umírat i další lidi", "sender" => "character4" ],
    [ "text" => "Velitel: Správně, takže tento případ bude obzvlášť těžký, ale to zvládneme", "sender" => "character1" ],
    [ "text" => "Velitel: Zahajuji tímto pátrání po tom, kdo to způsobil, kolik toho je a kde", "sender" => "character1" ],
    [ "text" => "Martin(v hlavě): doprkené ohrady, tak toto bude něco.", "sender" => "character2" ]
];
?>

<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zasedačka</title>
    <link rel="stylesheet" href="zasedacka2.css">
</head>
<body  background= "zasedacka_obarzky/conference_room.png">

<div class="dalsistrana">
<button class="dalsistranatlacitko" id="goToPage2">dalši strana</button>
</div>

<div id="chat-container">
    <div id="chat-box"></div>
    <button id="next-button">Další</button>
</div>

<!-- Vložíme JSON data generovaná PHP do JavaScriptu -->
<script>
    const messages = <?php echo json_encode($messages); ?>;
</script>

<!-- Externí JavaScript soubor -->
<script src="zasedacka2.js"></script>
</script>

</body>
</html>
