let index = 0;

const chatBox = document.getElementById("chat-box");
const nextButton = document.getElementById("next-button");

function showMessage() {
    chatBox.innerHTML = ""; // Vymaže předchozí zprávu

    if (index < messages.length) {
        const messageData = messages[index];
        const messageElement = document.createElement("div");
        messageElement.classList.add("message", messageData.sender);
        messageElement.textContent = messageData.text;
        chatBox.appendChild(messageElement);

        index++;
    } else {
        nextButton.disabled = true;
        nextButton.textContent = "Konec";
    }
}

nextButton.addEventListener("click", showMessage);

// Zobrazíme první zprávu hned na začátku
showMessage();


document.getElementById("goToPage2").addEventListener("click", function() {
    window.location.href = "byt/byt.php"; 
});
