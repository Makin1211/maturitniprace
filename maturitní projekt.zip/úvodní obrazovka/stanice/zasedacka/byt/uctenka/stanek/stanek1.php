<!DOCTYPE html>
<html lang="cs">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Byt</title>
    <link rel="stylesheet" href="stanek1.css">
</head>

<body background="stanecek_obr/stanek.png">

    <button id="btn1">Flaška ethanolu</button>
    <button id="btn2">Flaška methanolu</button>
    <button id="btn3" style="display: none;">Další</button>

    <script src="stanek1.js" defer></script>

</body>

</html>