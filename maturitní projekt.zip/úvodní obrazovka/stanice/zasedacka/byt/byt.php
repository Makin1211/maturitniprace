<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>byt</title>
    <link rel="stylesheet" href="byt.css">
</head>
<body background="byt_obrazky/byt_obrazek.JPEG">

    <button id="btn1">flaška alkoholu</button>
    <button id="btn2">postel, kde byla oběť</button>
    <button  id="btn3">další</button>

<script src="byt.js" defer></script>

</body>
</html>