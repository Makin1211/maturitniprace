document.getElementById("btn3").addEventListener("click", function() {
    window.location.href = "uctenka/uctenka.php"; 
});

let clicked1 = false;
let clicked2 = false;

document.getElementById("btn1").addEventListener("click", function() {
    clicked1 = true;
    checkButtons();
});

document.getElementById("btn2").addEventListener("click", function() {
    clicked2 = true;
    checkButtons();
});

function checkButtons() {
    if (clicked1 && clicked2) {
        document.getElementById("btn3").style.display = "block";
    }
}



