<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dialog s animací a tlačítkem</title>
    <link rel="stylesheet" href="zasedacka.css">
</head>
<body background="zasedacka_obarzky/zasedacka.png">

    <div class="character-container">
        <img id="charMartin" class="character-img left" src="zasedacka_obarzky/man.png" alt="Martin">
        <img id="charVeru" class="character-img right" src="https://via.placeholder.com/200/338DFF/FFFFFF?text=Veru" alt="Veru">
        <img id="charMata" class="character-img right" src="https://via.placeholder.com/200/33FF57/FFFFFF?text=Mata" alt="Mata">
    </div>

    <div class="dialog-container">
        <div id="dialog"></div>
        <button class="next-button" onclick="showNextLine()">Další</button>
    </div>

    <div class="next-page-container">
        <a id="nextPageButton" href="byt/byt.php" class="next-page-button" style="display:none;">Přejít na další stránku</a>
    </div>

    <script src="zasedacka.js"></script>

</body>
</html>
