<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Začátek</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <h1>Methanol, tichý zabiják</h1>

        <button id="goToPage2">Hrát</button>
    <script src="script.js"></script>
</body>
</html>
