document.getElementById("goToPage2").addEventListener("click", function() {
    window.location.href = "stanice/policejnistanicezacatek.php"; 
});
