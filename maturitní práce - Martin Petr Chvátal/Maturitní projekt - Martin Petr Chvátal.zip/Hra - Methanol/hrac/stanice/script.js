document.getElementById("goToPage2").addEventListener("click", function() {
    window.location.href = "zasedacka/zasedacka.html"; 
});
