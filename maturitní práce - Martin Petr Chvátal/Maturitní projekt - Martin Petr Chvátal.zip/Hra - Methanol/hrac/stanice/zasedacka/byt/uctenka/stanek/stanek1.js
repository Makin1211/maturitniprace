let clicked1 = false;
let clicked2 = false;

function updateCounter() {
    let count = (clicked1 ? 1 : 0) + (clicked2 ? 1 : 0);
    document.getElementById("counter").textContent = `${count}/2`;
    checkButtons();
}

document.getElementById("btn1").addEventListener("click", function() {
    if (!clicked1) {
        clicked1 = true;
        updateCounter();
    }
});

document.getElementById("btn2").addEventListener("click", function() {
    if (!clicked2) {
        clicked2 = true;
        updateCounter();
    }
});

document.getElementById("btn3").addEventListener("click", function() {
    window.location.href = "stanek_rozhovor/stanek.html";
});

function checkButtons() {
    if (clicked1 && clicked2) {
        document.getElementById("btn3").style.display = "block";
    }
}
