const playerName = localStorage.getItem("playerName") || "Hráč";
const dialogues = [
    { name: "Veru", text:  "Co jsi zatím našel?", img: "charVeru" },
    { name: playerName, text: "Mám tu flašku, ve které se pravděpodobně nachází methanol.", img: "charMartin" },
    { name: playerName, text: "A ještě postel, kde ji našli, co máš ty?", img: "charMartin" },
    { name: "Veru", text: "Já tu našla účtenku od té flašky, je to ze stánku, co se tady hned vedle paneláku.", img: "charVeru" },
    { name: playerName, text: "Co kdybysme se tam zašli podívat?", img: "charMartin" },
    { name: "Veru", text: "Jo můžem, to zní jako dobrý nápad.", img: "charVeru" },
    { name: playerName, text: "Tak jdeme.", img: "charMartin" }

];

let index = 0;
function showNextLine() {
    if (index < dialogues.length) {
        const line = dialogues[index];
        const dialogDiv = document.getElementById("dialog");
        dialogDiv.innerHTML = `<strong>${line.name}:</strong> <span class="message">${line.text}</span>`;

        document.getElementById("charMartin").classList.remove("show-left", "show-right");
        document.getElementById("charVeru").classList.remove("show-left", "show-right");
        
        const charImg = document.getElementById(line.img);
        if (line.img === "charMartin") {
            charImg.classList.add("show-left");
        } else {
            charImg.classList.add("show-right");
        }
        index++;
    } else {
        document.getElementById("dialog").innerHTML = "<em>Konec dialogu.</em>";
        document.getElementById("next-button").style.display = "none";
        document.getElementById("nextPageButton").style.display = "inline-block";
    }
}

document.getElementById("next-button").addEventListener("click", showNextLine);
showNextLine();