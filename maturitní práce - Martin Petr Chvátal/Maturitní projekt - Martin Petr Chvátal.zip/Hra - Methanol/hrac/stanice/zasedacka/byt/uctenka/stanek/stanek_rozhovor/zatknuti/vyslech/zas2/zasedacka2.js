const playerName = localStorage.getItem("playerName") || "Hráč";
const dialogues = [
    { name: "Mata", text: "Tak co? Jak vám to zatím jde?", img: "charMata" },
    { name: playerName, text: "Dobrý, pachatele jsme zatkly.", img: "charMartin" },
    { name: "Veru", text: "Dokonce se přiznal.", img: "charVeru" },
    { name: "Mata", text: "Výborně, to ráda slším, dobrá práce vy dva", img: "charMata" },
    { name: playerName, text: "Díky šéfová", img: "charMartin" },
    { name: "Veru", text: "Děkujeme.", img: "charVeru" },
    { name: "Mata", text: "Případ uzavřen", img: "charMata" }
];

let index = 0;
function showNextLine() {
    if (index < dialogues.length) {
        const line = dialogues[index];
        const dialogDiv = document.getElementById("dialog");
        dialogDiv.innerHTML = `<strong>${line.name}:</strong> <span class="message">${line.text}</span>`;

        document.getElementById("charMartin").classList.remove("show-left", "show-right");
        document.getElementById("charVeru").classList.remove("show-left", "show-right");
        document.getElementById("charMata").classList.remove("show-left", "show-right");
        
        const charImg = document.getElementById(line.img);
        if (line.img === "charMartin") {
            charImg.classList.add("show-left");
        } else {
            charImg.classList.add("show-right");
        }
        index++;
    } else {
        document.getElementById("dialog").innerHTML = "<em>Konec dialogu.</em>";
        document.getElementById("next-button").style.display = "none";
        document.getElementById("nextPageButton").style.display = "inline-block";
    }
}

document.getElementById("next-button").addEventListener("click", showNextLine);
showNextLine();