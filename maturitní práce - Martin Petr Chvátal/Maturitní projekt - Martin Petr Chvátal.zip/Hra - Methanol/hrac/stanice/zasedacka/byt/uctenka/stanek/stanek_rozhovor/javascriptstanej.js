const playerName = localStorage.getItem("playerName") || "Hráč";
const dialogues = [
    { name: playerName, text: "Dobrý den", img: "charMartin" },
    { name: "Veru", text: "Dobrý den, je tu někdo?", img: "charVeru" },
    { name: "Frolix", text: "Dobrý den, co si přejete?", img: "charProdavac" },
    { name: playerName, text: "Jsme od policie, řešíme případ.", img: "charMartin" },
    { name: "Veru", text: "Na místě činu byla nalezena účtenka od vašeho stánku.", img: "charVeru" },
    { name: "Veru", text: "Komu všemu jste prodal alkohol?", img: "charVeru" },
    { name: "Frolix", text: "Lidem hlavně z toho paneláku, někteří sem chodí celkem pravidelně.", img: "charProdavac" },
    { name: playerName, text: "Dnes jeden z nich zemřel na otravu ethanolem.", img: "charMartin" },
    { name: "Frolix", text: "Slyšel jsem něco, nevím, jak někdo mi to vůbec mohl dát.", img: "charProdavac" },
    { name: "Veru", text: "Kdo je váš oddavatel?", img: "charVeru" },
    { name: "Frolix", text: "Říkají mu Pilát, nevím jak se přesně jmenuje.", img: "charProdavac" },
    { name: playerName, text: "Pilát? z kalibiku?", img: "charMartin" },
    { name: "Veru", text: "Soustřeď se!!", img: "charVeru" },
    { name: "Veru", text: "Nevíte, kde bysme ho mohli najít?", img: "charVeru" },
    { name: "Frolix", text: "Jo, dám vám adresu.", img: "charProdavac" },
    { name: "Veru", text: "Děkujeme.", img: "charVeru" },
    { name: playerName, text: "To bude super, hned se tam půjdeme podívat.", img: "charMartin" },
];

let index = 0;
function showNextLine() {
    if (index < dialogues.length) {
        const line = dialogues[index];
        const dialogDiv = document.getElementById("dialog");
        dialogDiv.innerHTML = `<strong>${line.name}:</strong> <span class="message">${line.text}</span>`;

        document.getElementById("charMartin").classList.remove("show-left", "show-right");
        document.getElementById("charVeru").classList.remove("show-left", "show-right");
        document.getElementById("charProdavac").classList.remove("show-left", "show-right");
        
        const charImg = document.getElementById(line.img);
        if (line.img === "charMartin") {
            charImg.classList.add("show-left");
        } else {
            charImg.classList.add("show-right");
        }
        index++;
    } else {
        document.getElementById("dialog").innerHTML = "<em>Konec dialogu.</em>";
        document.getElementById("next-button").style.display = "none";
        document.getElementById("nextPageButton").style.display = "inline-block";
    }
}

document.getElementById("next-button").addEventListener("click", showNextLine);
showNextLine();
