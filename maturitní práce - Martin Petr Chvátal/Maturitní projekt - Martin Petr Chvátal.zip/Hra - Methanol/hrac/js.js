function saveName() {
    const name = document.getElementById("playerName").value;
    if (name.trim() !== "") {
        localStorage.setItem("playerName", name);
        alert("Jméno uloženo! Můžeš pokračovat do hry.");
        window.location.href = "stanice/policejnistanicezacatek.html"; // Přesměrování do hry
    } else {
        alert("Prosím, zadej své jméno.");
    }
}

// Načtení jména při startu hry
function getPlayerName() {
    return localStorage.getItem("playerName") || "Hráč";
}

